The list of Debian mirror sites is available here: https://www.debian.org/mirror/list
